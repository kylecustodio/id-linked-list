Kyle Custodio | kyc180000
Project 2
     P2Driver.java
     MyItem.java
     IDedObject.java
     IDedLinkedList.java
Development/Compilation
    JetBrains
    Java 11
Sample Commands
    java C:/Users/name/Documents/Project2/data/t1.txt C:/Users/name/Documents/Project2/output.txt

    => output.txt
        True
        True
        True
        37 47 109 475 694 88
        22 19 475 1238 9742
        34
        False
        True
        79
        Null
        ERROR
        ERROR
