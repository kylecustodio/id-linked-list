/**
 *  Kyle Custodio | kyc180000
 *  CS3345 | Data Structures and Intro to Algorithmic Analysis
 *  Section 001
 *  Fall 2019
 *  Project 2: Takes an input file via command line, performs the instructions as per the file on a LinkedList
 *              and outputs when instructed to to an output file, name chosen via command line.
 */

public interface IDedObject {
    int getID();
    String printID();
}
